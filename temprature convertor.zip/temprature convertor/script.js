const temperatureInput = document.getElementById('temperature');
const convertButton = document.getElementById('convert-button');
const unitSelect = document.getElementById('unit');
const convertedTempSpan = document.getElementById('converted-temperature');
const convertedUnitSpan = document.getElementById('converted-unit');

function convertTemperature() {
  const temperature = parseFloat(temperatureInput.value);
  const selectedUnit = unitSelect.value;
  let convertedTemperature;

  if (selectedUnit === 'celsius') {
    convertedTemperature = temperature;
    convertedUnitSpan.textContent = '°F';
  } else {
    convertedTemperature = (temperature * 9/5) + 32;
    convertedUnitSpan.textContent = '°C';
  }

  convertedTempSpan.textContent = convertedTemperature.toFixed(2);
}

convertButton.addEventListener('click', convertTemperature);
